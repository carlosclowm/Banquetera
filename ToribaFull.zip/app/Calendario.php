<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Calendario extends Model
{
    protected $table='calendario';
    protected $primaryKey='id';
    public $timestamps=false;
}
